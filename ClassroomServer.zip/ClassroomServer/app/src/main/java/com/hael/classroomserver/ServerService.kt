package com.hael.classroomserver

import android.app.*
import android.content.Context
import android.content.Intent
import android.net.wifi.WifiManager
import android.os.Build
import android.os.IBinder
import android.text.format.Formatter
import androidx.core.app.NotificationCompat
import java.io.File

class ServerService : Service() {

    companion object {
        const val CHANNEL_ID = "classroom_server_channel"
        const val NOTIF_ID = 1001
        const val PORT = 53222

        // مرجع عام بسيط يتيح لواجهة المستخدم الوصول للخادم الحالي أثناء التشغيل
        var runningServer: ClassroomHttpServer? = null
            private set
        var sharedFolderPath: String? = null
        var teacherName: String = "المعلم"
        var subjectName: String = "الصف"
    }

    private val binder = LocalBinder()

    inner class LocalBinder : android.os.Binder() {
        fun getService(): ServerService = this@ServerService
    }

    override fun onBind(intent: Intent?): IBinder = binder

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startForeground(NOTIF_ID, buildNotification())
        startServerIfNeeded()
        return START_STICKY
    }

    private fun startServerIfNeeded() {
        if (runningServer != null) return
        val server = ClassroomHttpServer(
            port = PORT,
            folderProvider = { listSharedFiles() },
            teacherName = teacherName,
            subjectName = subjectName
        )
        server.start(30_000, false)
        runningServer = server
    }

    private fun listSharedFiles(): List<SharedFile> {
        val folder = sharedFolderPath ?: return emptyList()
        val dir = File(folder)
        if (!dir.exists() || !dir.isDirectory) return emptyList()
        return dir.listFiles()
            ?.filter { it.isFile }
            ?.sortedByDescending { it.lastModified() }
            ?.map { f ->
                SharedFile(
                    id = f.name.hashCode().toString(),
                    name = f.name,
                    path = f.absolutePath,
                    sizeBytes = f.length()
                )
            } ?: emptyList()
    }

    fun getLocalIpAddress(): String {
        val wifiManager = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
        val ipInt = wifiManager.connectionInfo.ipAddress
        return if (ipInt != 0) Formatter.formatIpAddress(ipInt) else "غير متصل بشبكة Wi-Fi"
    }

    fun serverUrl(): String = "http://${getLocalIpAddress()}:$PORT"

    private fun buildNotification(): Notification {
        val builder = NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Classroom Server يعمل الآن")
            .setContentText("الطلاب يمكنهم الاتصال عبر ${serverUrl()}")
            .setSmallIcon(android.R.drawable.ic_menu_share)
            .setOngoing(true)
        return builder.build()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "خادم الصف",
                NotificationManager.IMPORTANCE_LOW
            )
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }
    }

    override fun onDestroy() {
        runningServer?.stop()
        runningServer = null
        super.onDestroy()
    }
}
