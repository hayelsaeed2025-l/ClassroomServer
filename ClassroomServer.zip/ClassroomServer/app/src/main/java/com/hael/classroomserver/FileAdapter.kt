package com.hael.classroomserver

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView

class FileAdapter(
    private var files: List<SharedFile>,
    private val onBroadcastClick: (SharedFile) -> Unit
) : RecyclerView.Adapter<FileAdapter.FileViewHolder>() {

    inner class FileViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val tvName: android.widget.TextView = view.findViewById(R.id.tvFileName)
        val tvSize: android.widget.TextView = view.findViewById(R.id.tvFileSize)
        val btnBroadcast: android.widget.Button = view.findViewById(R.id.btnBroadcast)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): FileViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_file, parent, false)
        return FileViewHolder(view)
    }

    override fun onBindViewHolder(holder: FileViewHolder, position: Int) {
        val file = files[position]
        holder.tvName.text = file.name
        holder.tvSize.text = file.sizeLabel()
        holder.btnBroadcast.setOnClickListener { onBroadcastClick(file) }
    }

    override fun getItemCount(): Int = files.size

    fun updateFiles(newFiles: List<SharedFile>) {
        files = newFiles
        notifyDataSetChanged()
    }
}
