package com.hael.classroomserver

import android.net.Uri
import fi.iki.elonen.NanoHTTPD
import java.io.File
import java.io.FileInputStream
import java.text.SimpleDateFormat
import java.util.*
import java.util.concurrent.ConcurrentHashMap

/**
 * الخادم المحلي المدمج داخل التطبيق.
 * يعمل عبر ServerSocket داخلي (مكتبة NanoHTTPD الخفيفة) بدون أي اتصال إنترنت.
 * كل طالب متصل بنفس شبكة Wi-Fi يفتح http://IP:PORT من متصفحه.
 */
class ClassroomHttpServer(
    port: Int,
    private val folderProvider: () -> List<SharedFile>,
    private val teacherName: String,
    private val subjectName: String
) : NanoHTTPD(port) {

    // سجل الأجهزة المتصلة: عنوان IP -> آخر وقت وصول + عدد الطلبات
    val connectedClients = ConcurrentHashMap<String, ClientInfo>()

    // معرف الملف المُذاع حاليًا (Broadcast) - null يعني لا يوجد بث نشط
    @Volatile
    var currentBroadcastId: String? = null
        private set

    data class ClientInfo(var lastSeen: Long, var requestCount: Int, var userAgent: String)

    fun setBroadcast(fileId: String?) {
        currentBroadcastId = fileId
    }

    private fun trackClient(session: IHTTPSession) {
        val ip = session.remoteIpAddress ?: "unknown"
        val ua = session.headers["user-agent"] ?: "device"
        val existing = connectedClients[ip]
        if (existing != null) {
            existing.lastSeen = System.currentTimeMillis()
            existing.requestCount += 1
        } else {
            connectedClients[ip] = ClientInfo(System.currentTimeMillis(), 1, ua)
        }
    }

    override fun serve(session: IHTTPSession): Response {
        trackClient(session)
        val uri = session.uri

        return try {
            when {
                uri == "/" -> serveIndex()
                uri == "/api/status" -> serveStatusJson()
                uri.startsWith("/file/") -> serveFile(uri.removePrefix("/file/"))
                else -> newFixedLengthResponse(Response.Status.NOT_FOUND, "text/plain", "404 - غير موجود")
            }
        } catch (e: Exception) {
            newFixedLengthResponse(
                Response.Status.INTERNAL_ERROR,
                "text/plain",
                "خطأ في الخادم: ${e.message}"
            )
        }
    }

    /** الصفحة الرئيسية التي يراها الطالب عند فتح عنوان IP الخاص بالمعلم */
    private fun serveIndex(): Response {
        val files = folderProvider()
        val filesHtml = if (files.isEmpty()) {
            "<p class='empty'>لا توجد ملفات متاحة حاليًا</p>"
        } else {
            files.joinToString("\n") { f ->
                """
                <div class="file-card" data-id="${f.id}">
                    <div class="file-icon">${iconFor(f.name)}</div>
                    <div class="file-info">
                        <div class="file-name">${escapeHtml(f.name)}</div>
                        <div class="file-meta">${f.sizeLabel()}</div>
                    </div>
                    <a class="open-btn" href="/file/${f.id}" target="_blank">فتح</a>
                </div>
                """.trimIndent()
            }
        }

        val html = """
        <!DOCTYPE html>
        <html lang="ar" dir="rtl">
        <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>$subjectName - $teacherName</title>
        <style>
            * { box-sizing: border-box; margin:0; padding:0; }
            body { font-family: 'Segoe UI', Tahoma, sans-serif; background:#f2f4f8; color:#222; padding:16px; }
            .header { background:linear-gradient(135deg,#1e3c72,#2a5298); color:#fff; padding:20px; border-radius:14px; margin-bottom:18px; text-align:center; }
            .header h1 { font-size:20px; margin-bottom:6px; }
            .header p { font-size:14px; opacity:0.9; }
            .file-card { display:flex; align-items:center; background:#fff; border-radius:12px; padding:14px; margin-bottom:10px; box-shadow:0 2px 6px rgba(0,0,0,0.08); }
            .file-icon { font-size:28px; margin-left:12px; }
            .file-info { flex:1; }
            .file-name { font-weight:600; font-size:15px; }
            .file-meta { font-size:12px; color:#777; margin-top:2px; }
            .open-btn { background:#2a5298; color:#fff; text-decoration:none; padding:8px 16px; border-radius:8px; font-size:14px; }
            .empty { text-align:center; color:#888; padding:30px; }
            #broadcastBanner { display:none; background:#e74c3c; color:#fff; padding:14px; border-radius:12px; margin-bottom:16px; text-align:center; font-weight:bold; animation:pulse 1.5s infinite; }
            @keyframes pulse { 0%{opacity:1} 50%{opacity:0.7} 100%{opacity:1} }
        </style>
        </head>
        <body>
            <div class="header">
                <h1>$subjectName</h1>
                <p>المعلم: $teacherName</p>
            </div>
            <div id="broadcastBanner">📢 المعلم أرسل ملفًا جديدًا الآن - اضغط هنا لفتحه</div>
            <div id="fileList">
                $filesHtml
            </div>

        <script>
        let lastBroadcast = null;
        async function checkBroadcast() {
            try {
                const res = await fetch('/api/status');
                const data = await res.json();
                const banner = document.getElementById('broadcastBanner');
                if (data.broadcastId && data.broadcastId !== lastBroadcast) {
                    lastBroadcast = data.broadcastId;
                    banner.style.display = 'block';
                    banner.onclick = () => window.open('/file/' + data.broadcastId, '_blank');
                } else if (!data.broadcastId) {
                    banner.style.display = 'none';
                }
            } catch (e) { /* الخادم غير متاح مؤقتًا */ }
        }
        setInterval(checkBroadcast, 3000);
        checkBroadcast();
        </script>
        </body>
        </html>
        """.trimIndent()

        return newFixedLengthResponse(Response.Status.OK, "text/html; charset=utf-8", html)
    }

    /** نقطة يستعلم عنها متصفح الطالب كل عدة ثوانٍ لمعرفة هل فيه بث جديد */
    private fun serveStatusJson(): Response {
        val json = """{"broadcastId": ${if (currentBroadcastId != null) "\"$currentBroadcastId\"" else "null"}, "clientCount": ${connectedClients.size}}"""
        return newFixedLengthResponse(Response.Status.OK, "application/json", json)
    }

    /** إرسال محتوى ملف فعلي للطالب عند الضغط على "فتح" */
    private fun serveFile(fileId: String): Response {
        val target = folderProvider().find { it.id == fileId }
            ?: return newFixedLengthResponse(Response.Status.NOT_FOUND, "text/plain", "الملف غير موجود")

        val file = File(target.path)
        if (!file.exists()) {
            return newFixedLengthResponse(Response.Status.NOT_FOUND, "text/plain", "الملف غير موجود على الجهاز")
        }

        val mime = mimeTypeFor(file.name)
        val fis = FileInputStream(file)
        val response = newFixedLengthResponse(Response.Status.OK, mime, fis, file.length())
        response.addHeader("Content-Disposition", "inline; filename=\"${file.name}\"")
        return response
    }

    private fun mimeTypeFor(name: String): String = when {
        name.endsWith(".html", true) || name.endsWith(".htm", true) -> "text/html; charset=utf-8"
        name.endsWith(".pdf", true) -> "application/pdf"
        name.endsWith(".png", true) -> "image/png"
        name.endsWith(".jpg", true) || name.endsWith(".jpeg", true) -> "image/jpeg"
        name.endsWith(".mp4", true) -> "video/mp4"
        name.endsWith(".mp3", true) -> "audio/mpeg"
        name.endsWith(".webp", true) -> "image/webp"
        else -> "application/octet-stream"
    }

    private fun iconFor(name: String): String = when {
        name.endsWith(".html", true) || name.endsWith(".htm", true) -> "🌐"
        name.endsWith(".pdf", true) -> "📕"
        name.endsWith(".png", true) || name.endsWith(".jpg", true) || name.endsWith(".jpeg", true) -> "🖼️"
        name.endsWith(".mp4", true) -> "🎬"
        name.endsWith(".mp3", true) -> "🎵"
        else -> "📄"
    }

    private fun escapeHtml(s: String): String = s
        .replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;")

    fun activeClientCount(windowMillis: Long = 60_000): Int {
        val now = System.currentTimeMillis()
        return connectedClients.values.count { now - it.lastSeen < windowMillis }
    }
}

/** يمثل ملفًا واحدًا متاحًا للمشاركة */
data class SharedFile(
    val id: String,
    val name: String,
    val path: String,
    val sizeBytes: Long
) {
    fun sizeLabel(): String {
        val kb = sizeBytes / 1024.0
        return if (kb < 1024) "%.0f KB".format(kb) else "%.1f MB".format(kb / 1024.0)
    }
}
