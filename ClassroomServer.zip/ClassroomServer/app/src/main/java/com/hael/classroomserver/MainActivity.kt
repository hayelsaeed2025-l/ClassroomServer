package com.hael.classroomserver

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.DocumentsContract
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.documentfile.provider.DocumentFile
import androidx.recyclerview.widget.LinearLayoutManager
import com.hael.classroomserver.databinding.ActivityMainBinding
import java.io.File
import java.io.FileOutputStream

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var adapter: FileAdapter
    private val refreshHandler = Handler(Looper.getMainLooper())
    private var isServerRunning = false

    // مجلد محلي داخل التطبيق يُنسخ إليه الملفات المختارة (لضمان قراءتها بسرعة وموثوقية)
    private val localSyncFolder: File by lazy {
        File(getExternalFilesDir(null), "shared_files").apply { mkdirs() }
    }

    private val folderPickerLauncher = registerForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.OpenDocumentTree()
    ) { uri: Uri? ->
        if (uri != null) {
            contentResolver.takePersistableUriPermission(
                uri,
                Intent.FLAG_GRANT_READ_URI_PERMISSION
            )
            syncFolderFromUri(uri)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // اسم المعلم والمادة - يمكن تعديلهما لاحقًا بإضافة شاشة إعدادات
        ServerService.teacherName = "هايل"
        ServerService.subjectName = "English Course Book 4"
        ServerService.sharedFolderPath = localSyncFolder.absolutePath

        adapter = FileAdapter(emptyList()) { file -> broadcastFile(file) }
        binding.recyclerFiles.layoutManager = LinearLayoutManager(this)
        binding.recyclerFiles.adapter = adapter

        binding.btnPickFolder.setOnClickListener { folderPickerLauncher.launch(null) }
        binding.btnToggleServer.setOnClickListener { toggleServer() }

        refreshFileList()
    }

    private fun toggleServer() {
        if (!isServerRunning) {
            val intent = Intent(this, ServerService::class.java)
            startForegroundService(intent)
            isServerRunning = true
            binding.btnToggleServer.text = "إيقاف الخادم"
            binding.tvServerStatus.text = "الخادم يعمل الآن ✅"
            startStatusPolling()
        } else {
            stopService(Intent(this, ServerService::class.java))
            isServerRunning = false
            binding.btnToggleServer.text = "تشغيل الخادم"
            binding.tvServerStatus.text = "الخادم متوقف"
            binding.tvServerUrl.text = ""
            binding.tvClientCount.text = "عدد الأجهزة المتصلة: 0"
            refreshHandler.removeCallbacksAndMessages(null)
        }
    }

    /** يستنسخ الملفات من المجلد الذي اختاره المعلم إلى مجلد داخلي يقدر الخادم يقرأه مباشرة */
    private fun syncFolderFromUri(treeUri: Uri) {
        Toast.makeText(this, "جارٍ نسخ الملفات...", Toast.LENGTH_SHORT).show()
        val docTree = DocumentFile.fromTreeUri(this, treeUri)
        var count = 0
        docTree?.listFiles()?.forEach { doc ->
            if (doc.isFile && doc.name != null) {
                try {
                    contentResolver.openInputStream(doc.uri)?.use { input ->
                        val outFile = File(localSyncFolder, doc.name!!)
                        FileOutputStream(outFile).use { output -> input.copyTo(output) }
                        count++
                    }
                } catch (e: Exception) {
                    // تجاهل الملف الذي تعذّر نسخه ومتابعة الباقي
                }
            }
        }
        binding.tvFolderPath.text = "تم نسخ $count ملف من: ${docTree?.name ?: treeUri.lastPathSegment}"
        Toast.makeText(this, "تم تحديث $count ملف", Toast.LENGTH_SHORT).show()
        refreshFileList()
    }

    private fun refreshFileList() {
        val files = localSyncFolder.listFiles()
            ?.filter { it.isFile }
            ?.sortedByDescending { it.lastModified() }
            ?.map { f -> SharedFile(id = f.name.hashCode().toString(), name = f.name, path = f.absolutePath, sizeBytes = f.length()) }
            ?: emptyList()
        adapter.updateFiles(files)
    }

    private fun broadcastFile(file: SharedFile) {
        val server = ServerService.runningServer
        if (server == null) {
            Toast.makeText(this, "شغّل الخادم أولًا", Toast.LENGTH_SHORT).show()
            return
        }
        server.setBroadcast(file.id)
        Toast.makeText(this, "تم إرسال \"${file.name}\" لجميع الطلاب", Toast.LENGTH_SHORT).show()
    }

    /** يحدّث عنوان IP وعدد الأجهزة المتصلة كل ثانيتين أثناء عمل الخادم */
    private fun startStatusPolling() {
        val runnable = object : Runnable {
            override fun run() {
                val service = ServerService.runningServer
                if (service != null) {
                    val ip = try {
                        (getSystemService(WIFI_SERVICE) as android.net.wifi.WifiManager)
                            .connectionInfo.ipAddress
                    } catch (e: Exception) { 0 }
                    val ipStr = if (ip != 0) {
                        android.text.format.Formatter.formatIpAddress(ip)
                    } else "تحقق من اتصال Wi-Fi"
                    binding.tvServerUrl.text = "http://$ipStr:${ServerService.PORT}"
                    binding.tvClientCount.text = "عدد الأجهزة المتصلة: ${service.activeClientCount()}"
                }
                refreshFileList()
                refreshHandler.postDelayed(this, 2000)
            }
        }
        refreshHandler.post(runnable)
    }

    override fun onDestroy() {
        refreshHandler.removeCallbacksAndMessages(null)
        super.onDestroy()
    }
}
